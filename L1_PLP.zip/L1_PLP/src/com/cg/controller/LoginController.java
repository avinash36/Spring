package com.cg.controller;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
import com.cg.service.ILoginService;

@Controller
public class LoginController {
	@Autowired
	ILoginService logSer=null;

	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}

	@RequestMapping(value="/ShowLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login user=new Login();
		model.addAttribute("user", user);
		model.addAttribute("loginCapStore", "Welcome to CapStore");
		return "Login";
	}

	@RequestMapping(value="/ShowMerchantPage", method=RequestMethod.GET)
	public String displayMerchantPage(Model model) {
		MerchantLogin merchant=new MerchantLogin();
		model.addAttribute("merchant",merchant);
		model.addAttribute("loginCapStore", "Welcome to CapStore");
		return "MerchantLogin";
	}
	/************************Validate User*******************/
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="user") 
	@Valid Login user,BindingResult result,Model model) {
		if(result.hasErrors()) {
			return "Login";
		}else if (logSer.isUserExist(user.getUserEmail())) {
			Login user1=logSer.validateUser(user);
			if(user1!=null){
				model.addAttribute("unmObj",user.getUserEmail());
				return "Success";
			}else {
				return "Failure";
			}
		}else {
			return  "Login";
		}
	}
		@RequestMapping(value="/ValidateMerchant", method=RequestMethod.POST)
		public String validateMerchantDetails(@ModelAttribute(value="merchant") 
		@Valid MerchantLogin merchant, BindingResult result,Model model) {
			if(result.hasErrors()) {
				return "MerchantLogin";
			}else if (logSer.isUserExist(merchant.getMerchant_emailId())) {
				MerchantLogin user1=logSer.validateUser(merchant);
				if(user1!=null){
					model.addAttribute("unmObj",merchant.getMerchant_emailId());
					return "Success";
				}else {
					return "Failure";
				}
			}else {
				return  "MerchantLogin";
			}
		}
}
/*		if(result.hasErrors()) {
			return "MerchantLogin";
		}
		else if(logSer.isUserExist(mlg.getMerchant_emailId())) {
			MerchantLogin muser=logSer.validateUser(mlg);
			if(muser!=null){
				model.addAttribute("unmObj",mlg.getMerchant_emailId());
				return "Success";
			}else {
				return "Failure";
			}
		}else {
			return  "MerchantLogin";
		}*/

