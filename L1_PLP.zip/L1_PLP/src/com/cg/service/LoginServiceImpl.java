package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
import com.cg.dto.RegisterNewUser;
@Service("loginSer")
public class LoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDao logDao=null;
	public ILoginDao getLogDao() {
		return logDao;
	}

	public void setLogDao(ILoginDao logDao) {
		this.logDao = logDao;
	}

	@Override
	public boolean isUserExist(String usn) {
		return logDao.isUserExist(usn);
	}

	@Override
	public Login validateUser(Login login) {
		Login dbUser=logDao.validateUser(login);
		if (login.getUserEmail().equalsIgnoreCase(dbUser.getUserEmail())&& login.getPassword().equalsIgnoreCase(dbUser.getPassword())){
			return login;
		}else {
			return null;
		}
	}

	@Override
	public RegisterNewUser newUser(RegisterNewUser regUser) {
	
		return null;
	}

	@Override
	public RegisterNewUser newMerchantUser(RegisterNewUser regAdmin) {
	
		return null;
	}

	@Override
	public MerchantLogin validateUser(MerchantLogin mlogin) {
		// TODO Auto-generated method stub
		return null;
	}

}