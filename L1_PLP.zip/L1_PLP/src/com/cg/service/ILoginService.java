package com.cg.service;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
import com.cg.dto.RegisterNewUser;

public interface ILoginService {
	public boolean isUserExist(String usn);
	public Login validateUser(Login login);
	public MerchantLogin validateUser(MerchantLogin mlogin);
	public RegisterNewUser newUser(RegisterNewUser regUser);
	public RegisterNewUser newMerchantUser(RegisterNewUser regAdmin);
}
