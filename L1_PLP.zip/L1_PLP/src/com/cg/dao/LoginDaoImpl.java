package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
import com.cg.dto.RegisterNewUser;
@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String usn) {
		Login usr=entityManager.find(Login.class, usn);
		if(usr!=null) {
			return true;
		}else {
			return false;
		}	
	}

	@Override
	public Login validateUser(Login login) {
		Login usr=entityManager.find(Login.class,login.getUserEmail());
		return usr;
	}

	@Override
	public RegisterNewUser newUser(RegisterNewUser regUser) {
		Login logObj=new Login();
		logObj.setUserEmail(regUser.getUname());
		logObj.setPassword(regUser.getPassword());
		entityManager.persist(regUser);
		entityManager.persist(logObj);
		entityManager.flush();
		RegisterNewUser reg=entityManager.find(RegisterNewUser.class, regUser.getUname());
		return reg;
	}

	@Override
	public RegisterNewUser newMerchantUser(RegisterNewUser regAdmin) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MerchantLogin validateUser(MerchantLogin mlogin) {
		// TODO Auto-generated method stub
		return null;
	}


}
/*@Override
	public RegisterDto insertuserDetails(RegisterDto userDetails) {

	}*/