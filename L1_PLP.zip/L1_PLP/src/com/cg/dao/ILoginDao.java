package com.cg.dao;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
import com.cg.dto.RegisterNewUser;

public interface ILoginDao {
	public boolean isUserExist(String usn);
	public Login validateUser(Login login);
	public MerchantLogin validateUser(MerchantLogin mlogin);
	public RegisterNewUser newUser(RegisterNewUser regUser);
	public RegisterNewUser newMerchantUser(RegisterNewUser regAdmin);
}
