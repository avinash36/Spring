package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.bean.Address;
import com.cg.bean.Login;
import com.cg.bean.MerchantLogin;
import com.cg.bean.User;
@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager=null;
	public LoginDaoImpl() {
		super();
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String usn) {
		Login usr=entityManager.find(Login.class, usn);
		if(usr!=null) {
			return true;
		}else {
			return false;
		}	
	}

	@Override
	public Login validateUser(Login login) {
		Login usr=entityManager.find(Login.class,login.getUserEmail());
		return usr;
	}

	@Override
	public MerchantLogin validateMerchant(MerchantLogin mlogin) {
		MerchantLogin mlog=entityManager.find(MerchantLogin.class,mlogin.getMerchant_emailId());
		return mlog;
	}

	@Override
	public boolean isMercUserExist(String musn) {
		MerchantLogin mlog=entityManager.find(MerchantLogin.class, musn);
		if(mlog!=null) {
			return true;
		}else {
			return false;
		}	
	}

	@Override
	public User addUser(User register) {
		entityManager.persist(register);
		entityManager.flush();
		return register;
	}

	@Override
	public Address addAddress(Address address, User user) {
		entityManager.persist(address);
		entityManager.flush();
		return address;
	}

	@Override
	public User findByEmail(String email) {
		Query query = entityManager.createQuery("from User u where u.email=:email ");
		query.setParameter("email", email);
		//System.out.println("dao details................."+(User_details)query.getSingleResult());
		return (User)query.getSingleResult();
	}
}