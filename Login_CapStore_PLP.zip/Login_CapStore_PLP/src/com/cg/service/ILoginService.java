package com.cg.service;
import com.cg.bean.Address;
import com.cg.bean.Login;
import com.cg.bean.MerchantLogin;
import com.cg.bean.User;

public interface ILoginService {
	public boolean isUserExist(String usn);
	public boolean isMercUserExist(String musn);
	public Login validateUser(Login login);
	public MerchantLogin validateMerchant(MerchantLogin mlogin);
	public User addUser(User register);
	public Address addAddress(Address address,User user);
	public User findByEmail(String email);
}
