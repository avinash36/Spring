package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Address;
import com.cg.bean.Login;
import com.cg.bean.MerchantLogin;
import com.cg.bean.User;
import com.cg.dao.ILoginDao;
@Service("loginSer")
public class LoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDao logDao=null;
	 static int num=100;
		static int num1=100;
		
		public static  int getNum() {
			return ++num;
		}
		public static int getNum1() {
			return ++num1;
		}
		
	public LoginServiceImpl() {
		super();
	}

	public ILoginDao getLogDao() {
		return logDao;
	}

	public void setLogDao(ILoginDao logDao) {
		this.logDao = logDao;
	}

	@Override
	public boolean isUserExist(String usn) {
		return logDao.isUserExist(usn);
	}

	@Override
	public Login validateUser(Login login) {
		Login dbUser=logDao.validateUser(login);
		if (login.getUserEmail().equalsIgnoreCase(dbUser.getUserEmail())&& login.getPassword().equalsIgnoreCase(dbUser.getPassword())){
			return login;
		}else {
			return null;
		}
	}

	@Override
	public MerchantLogin validateMerchant(MerchantLogin mlogin) {
		MerchantLogin dbmlogin=logDao.validateMerchant(mlogin);
		if (mlogin.getMerchant_emailId().equalsIgnoreCase(dbmlogin.getMerchant_emailId())&& mlogin.getPassword().equalsIgnoreCase(dbmlogin.getPassword())){
			return mlogin;
		}else {
			return null;
		}
	}

	@Override
	public boolean isMercUserExist(String musn) {
		return logDao.isMercUserExist(musn);
	}
	@Override
	public User addUser(User register) {
		StringBuilder str=new StringBuilder();
		str.append("U"+getNum());
	
		register.setUser_id(str.toString());
		System.out.println(str);
		register.setUserRole("User");
		return logDao.addUser(register);
	}
	@Override
	public Address addAddress(Address address, User user) {
		StringBuilder str2=new StringBuilder();
		str2.append("A"+getNum1());
		address.setAddress_id(str2.toString());
		address.setCountry("India");
		address.setUser(user);


		return logDao.addAddress(address, user);
	}
	@Override
	public User findByEmail(String email) {
		//System.out.println("service..............."+capstoreDao.findByEmail(email));
				return logDao.findByEmail(email);
	}
	
}