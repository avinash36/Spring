package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cg.bean.Address;
import com.cg.bean.Login;
import com.cg.bean.MerchantLogin;
import com.cg.bean.User;
import com.cg.service.ILoginService;

@Controller
@SessionAttributes("userDetails")
public class LoginController {
	@Autowired
	ILoginService logSer=null;
	
	ArrayList<String>stateList;

	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}

	@RequestMapping(value="/ShowLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login user=new Login();
		model.addAttribute("userLog", user);
		model.addAttribute("loginCapStore", "Welcome to CapStore");
		return "Login";
	}
	
	/************************** Merchant Login************************/
	@RequestMapping(value="/ShowMerchantLogin", method=RequestMethod.GET)
	public String displayMerchantPage(Model model) {	
		MerchantLogin merchant=new MerchantLogin();
		model.addAttribute("merchantLog",merchant);
		model.addAttribute("loginCapStore", "Welcome to CapStore");
		return "MerchantLogin";
	}
	
	
	/************************Validate User*******************/
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="userLog") 
	@Valid Login user,BindingResult result,Model model) {
		model.addAttribute("userDetails", user.getUserEmail());
		if(result.hasErrors()) {
			return "Login";
		}else if (logSer.isUserExist(user.getUserEmail())) {
			User user_details = logSer.findByEmail(user.getAdminEmail());
		
			if(user_details.getUser_type().equals("Admin")) {}
			
			return "adminPage";
			Login user1=logSer.validateUser(user);
			if(user1!=null){
				model.addAttribute("userlogin",user.getUserEmail());
				return "Home";
			}else {
				return "RegisterPage";
			}
		}else {
			return  "Login";
		}
	}
	
	/************************Validate Merchant*******************/
		@RequestMapping(value="/ValidateMerchant", method=RequestMethod.POST)
		public String validateMerchantDetails(@ModelAttribute(value="merchantLog") 
		@Valid MerchantLogin merchant,BindingResult result,Model model) {
			model.addAttribute("userDetails", merchant.getMerchant_emailId());
			if(result.hasErrors()) {
				return "MerchantLogin";
			}else if (logSer.isMercUserExist(merchant.getMerchant_emailId())) {
				MerchantLogin muser1=logSer.validateMerchant(merchant);
				if(muser1!=null){
					model.addAttribute("merchantlogin",merchant.getMerchant_emailId());
					return "Success2";
				}else {
					return "RegisterPage";
				}
			}else {
				return  "MerchantLogin";
			}
	}
		@RequestMapping(value="logout",method=RequestMethod.GET )
		public String logoutUser(Model model) {
			return "logout";
		}
		
		
	/***************************************************/
		User user;
		@RequestMapping(value="/addUser",method=RequestMethod.GET)
		public String displayRegisterPage(Model model) {
			model.addAttribute("add", new User());

			return "RegisterPage";
		}
		@RequestMapping(value="/Insert", method=RequestMethod.POST)
		public String addUserDetails(@ModelAttribute(value="add") @Valid User register,BindingResult result,Model model) {
		
			if(result.hasErrors()) {
				return "RegisterPage";

			}
			else {
				user=logSer.addUser(register);
				model.addAttribute("address", new Address());
				return "AddressPage";
			}
			
		}

		@ModelAttribute("stateList")
		public ArrayList<String> createStateList() {
			ArrayList<String> stateList=new ArrayList<>();
			stateList.add("Andhra Pradesh");stateList.add("Arunachal Pradesh");stateList.add("Assam");
			stateList.add("Bihar");stateList.add("Chhattisgarh");stateList.add("Goa");stateList.add("Gujarat");
			stateList.add("Haryana");stateList.add("Himachal Pradesh");stateList.add("Jammu & Kashmir");
			stateList.add("Jharkhand");stateList.add("Karnataka");stateList.add("Kerala");stateList.add("Madhya Pradesh");
			stateList.add("Maharashtra");stateList.add("Manipur");stateList.add("Meghalaya");stateList.add("Mizoram");
			stateList.add("Nagaland");stateList.add("Odisha");stateList.add("Punjab");stateList.add("Rajasthan");
			stateList.add("Sikkim");stateList.add("Tamil Nadu");stateList.add("Telangana");stateList.add("Tripura");
			stateList.add("Uttarakhand");stateList.add("Uttar Pradesh");stateList.add("West Bengal");
			return stateList;

		}

		@RequestMapping(value="/Insert1", method=RequestMethod.POST)
		public String addAddressDetails(@ModelAttribute(value="stateList") 
		ArrayList<String> stateList,@Valid Address address,BindingResult result,Model model) {
			
			if(result.hasErrors()) {
				model.addAttribute("stateList",stateList);
				return "AddressPage";

			}
			else {
				logSer.addAddress(address,user);
				model.addAttribute("msg1","user is successfully registered");
				return "AddressPage";
				
			}
		
		}
}