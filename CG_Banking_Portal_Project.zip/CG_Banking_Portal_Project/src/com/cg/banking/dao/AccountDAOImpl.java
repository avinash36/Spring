package com.cg.banking.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Account;

@Repository
@Transactional
public class AccountDAOImpl implements AccountDAO {

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Account save(Account account) {
		entityManager.persist(account);
		return account;
	}

	@Override
	public boolean update(Account account) {
		entityManager.merge(account);
		return true;
	}

	@Override
	public Account findOne(long accountNo) {
		return entityManager.find(Account.class, accountNo);
	}
	
	@Override
	public List<Account> findAll(String mobile) {
		return entityManager.createQuery("from Account a where customer_mobile="+mobile,Account.class).getResultList();
	}
}