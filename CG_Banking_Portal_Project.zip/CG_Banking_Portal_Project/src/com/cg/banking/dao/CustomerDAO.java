package com.cg.banking.dao;

import java.util.List;

import com.cg.banking.beans.Customer;

public interface CustomerDAO {
	Customer save(Customer customer);

	boolean update(Customer customer);

	Customer findOne(String mobile);

	List<Customer> findAll();
}