package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.dao.AccountDAO;
import com.cg.banking.dao.CustomerDAO;
import com.cg.banking.dao.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Service
public class BankingServicesImpl implements BankingServices {

	@Autowired
	CustomerDAO customerDAO;
	@Autowired
	AccountDAO accountDAO;
	@Autowired
	TransactionDAO transactionDAO;

	public CustomerDAO getCustomerDAO() {
		return customerDAO;
	}

	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}

	public AccountDAO getAccountDAO() {
		return accountDAO;
	}

	public void setAccountDAO(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}

	public TransactionDAO getTransactionDAO() {
		return transactionDAO;
	}

	public void setTransactionDAO(TransactionDAO transactionDAO) {
		this.transactionDAO = transactionDAO;
	}

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account = new Account();
		if (!accountType.equalsIgnoreCase("salary") && !accountType.equalsIgnoreCase("current")
				&& !accountType.equalsIgnoreCase("savings"))
			throw new InvalidAccountTypeException();
		else
			account.setAccountType(accountType);

		if (initBalance < 500)
			throw new InvalidAmountException();
		else
			account.setAccountBalance(initBalance);

		account.setPinNumber((int) (Math.random() * 9000) + 1000);
		account.setStatus("active");
		accountDAO.save(account);
		transactionDAO.save(new Transaction(initBalance, "Initialize", account));
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account = accountDAO.findOne(accountNo);
		if (account == null)
			throw new AccountNotFoundException();
		if (!account.getStatus().equalsIgnoreCase("active"))
			throw new AccountBlockedException();
		else
			account.setAccountBalance(account.getAccountBalance() + amount);
		accountDAO.update(account);
		transactionDAO.save(new Transaction(amount, "Deposit", account));
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,

			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account = accountDAO.findOne(accountNo);
		if (account == null)
			throw new AccountNotFoundException();
		if (pinNumber != account.getPinNumber())
			throw new InvalidPinNumberException();
		if (!account.getStatus().equalsIgnoreCase("active"))
			throw new AccountBlockedException();
		if (account.getAccountBalance() < amount)
			throw new InsufficientAmountException();
		else
			account.setAccountBalance(account.getAccountBalance() - amount);
		accountDAO.update(account);
		transactionDAO.save(new Transaction(amount, "Withdraw", account));
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)

			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account payer = accountDAO.findOne(accountNoFrom);
		Account payee = accountDAO.findOne(accountNoTo);
		if (payer == null || payee == null)
			throw new AccountNotFoundException();
		if (pinNumber != payer.getPinNumber())
			throw new InvalidPinNumberException();
		if (!payer.getStatus().equalsIgnoreCase("active") || !payee.getStatus().equalsIgnoreCase("active"))
			throw new AccountBlockedException();
		if (payer.getAccountBalance() < transferAmount)
			throw new InsufficientAmountException();
		payer.setAccountBalance(payer.getAccountBalance() - transferAmount);
		payee.setAccountBalance(payee.getAccountBalance() + transferAmount);
		accountDAO.update(payee);
		accountDAO.update(payer);
		transactionDAO.save(new Transaction(transferAmount, "Debited", payer));
		transactionDAO.save(new Transaction(transferAmount, "Credited", payee));
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		if (accountDAO.findOne(accountNo) == null)
			throw new AccountNotFoundException();
		return accountDAO.findOne(accountNo);
	}

	@Override
	public List<Account> getAllAccountDetails(String mobile) throws BankingServicesDownException {
		return accountDAO.findAll(mobile);
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		Account account = accountDAO.findOne(accountNo);
		if (account == null)
			throw new AccountNotFoundException();
		return transactionDAO.findAll(accountNo);
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account = accountDAO.findOne(accountNo);
		if (account == null)
			throw new AccountNotFoundException();
		if (!account.getStatus().equalsIgnoreCase("active"))
			throw new AccountBlockedException();
		return account.getStatus();
	}
}