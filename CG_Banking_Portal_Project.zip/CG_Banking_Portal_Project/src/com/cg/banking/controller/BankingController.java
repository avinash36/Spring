package com.cg.banking.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BankingController {
	//OpenAccountPage.obj
	
	
}