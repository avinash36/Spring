package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Emp;
import com.cg.bean.Employee;

public class TestEmpDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
		Employee emp1=(Employee) ctx.getBean("aviObj");
		System.out.println("*****EMP INFO******");
		System.out.println(" ID: "+emp1.getEmpId()+"\n Name: "+emp1.getEmpName()
												+"\n Salary: "+emp1.getEmpSal()+"\n Emp Address: "+emp1.getEmpAdd().getState()
												+","+emp1.getEmpAdd().getCity()+","+emp1.getEmpAdd().getZipCode());
		
		System.out.println("********************************************************************");
		Emp emp2=(Emp) ctx.getBean("satObj");
		System.out.println("*****EMP INFO******");
		System.out.println(" ID: "+emp2.getEmpId()+"\n Name: "+emp2.getEmpName()
												+"\n Salary: "+emp2.getEmpSal()+"\n Emp Address: "+emp2.getEmpAdd());
	}

}
