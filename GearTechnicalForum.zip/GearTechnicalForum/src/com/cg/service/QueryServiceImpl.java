package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDao;
import com.cg.dto.Query;

@Service
public class QueryServiceImpl implements IQueryService{
	@Autowired
	IQueryDao queryDao=null;

	public IQueryDao getQueryDao() {
		return queryDao;
	}

	public void setQueryDao(IQueryDao queryDao) {
		this.queryDao = queryDao;
	}

	@Override
	public Query searchQuery(int id) {
		return queryDao.searchQuery(id);
	}

	@Override
	public Query update(Query query) {
		return queryDao.update(query);
	}
	
}
