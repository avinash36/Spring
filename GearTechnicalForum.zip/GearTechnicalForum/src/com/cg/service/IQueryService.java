package com.cg.service;

import com.cg.dto.Query;

public interface IQueryService {
	public Query searchQuery(int id);
	public Query update(Query query);
}
