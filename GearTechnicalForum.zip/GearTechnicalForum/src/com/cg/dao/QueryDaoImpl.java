package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Query;

@Repository
@Transactional
public class QueryDaoImpl implements IQueryDao {
	@PersistenceContext
	EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Query searchQuery(int id) {
		return entityManager.find(Query.class, id);
	}

	@Override
	public Query update(Query query) {
		entityManager.merge(query);
		return query;
	}
}
