package com.cg.dao;

import com.cg.dto.Query;

public interface IQueryDao {
	public Query searchQuery(int id);
	public Query update(Query query);
}
