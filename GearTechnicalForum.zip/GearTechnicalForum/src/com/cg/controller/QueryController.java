package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dto.Query;
import com.cg.service.IQueryService;

@Controller
public class QueryController {
	@Autowired
	IQueryService queryService=null;

	public IQueryService getQueryService() {
		return queryService;
	}

	public void setQueryService(IQueryService queryService) {
		this.queryService = queryService;
	}


	/*******************Go To Index Page*********************/
	@RequestMapping(value="/Index", method=RequestMethod.GET)
	public String goToIndex(Model model) {
		model.addAttribute("quer", new Query());
		return "Index";
	}


	/************************Search Query*******************/
	@RequestMapping(value="/Query", method=RequestMethod.POST)
	public String getAllHotelList(@ModelAttribute(value="quer") Query query,BindingResult result, Model model) {
		ArrayList<String> names=new ArrayList<String>();
		names.add("Smith");
		names.add("John");
		names.add("Rahul");
		names.add("Abhishek");
		
		query= queryService.searchQuery(query.getId());
		if(query!=null) {
		model.addAttribute("ansBy", names);
		model.addAttribute("queListObj", query);
		return "QueryDetails";
		}else {
			return "Failure";
		}
	}

	/******************************Update Query*****************/
	@RequestMapping(value="/Success",method=RequestMethod.POST)
	public String Update(@ModelAttribute(value="queListObj")Query query,BindingResult bindingResult,Model model){
		Query qt=queryService.update(query);
		model.addAttribute("qt", qt);
		return"Success";
	}
}
