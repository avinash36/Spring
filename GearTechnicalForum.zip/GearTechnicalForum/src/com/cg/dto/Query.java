package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="query_master")
public class Query {
	@Id
	@Column(name="query_id")
	private int id;

	@Column(name="technology")
	private String technology;

	@Column(name="query_raised_by")
	private String raisedBy;

	@Column(name="query")
	private String query;

	@Column(name="solutions")
	private String solutions;

	@Column(name="solution_given_by")
	private String givenBy;

	public Query() {}

	public Query(int id, String technology, String raisedBy, String query, String solutions, String givenBy) {
		super();
		this.id = id;
		this.technology = technology;
		this.raisedBy = raisedBy;
		this.query = query;
		this.solutions = solutions;
		this.givenBy = givenBy;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getGivenBy() {
		return givenBy;
	}

	public void setGivenBy(String givenBy) {
		this.givenBy = givenBy;
	}

	@Override
	public String toString() {
		return "Query [id=" + id + ", technology=" + technology + ", raisedBy=" + raisedBy + ", query=" + query
				+ ", solutions=" + solutions + ", givenBy=" + givenBy + "]";
	}

}
