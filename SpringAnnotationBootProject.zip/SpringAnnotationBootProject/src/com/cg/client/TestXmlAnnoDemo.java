package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.IGreet;

public class TestXmlAnnoDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXmlAnno.xml");
		IGreet g1=(IGreet) ctx.getBean("obj1");
		System.out.println(g1.greetMe());
		
		System.out.println("________________________");
		IGreet g2=(IGreet) ctx.getBean("obj2");
		System.out.println(g2.greetMe());
	}

}
