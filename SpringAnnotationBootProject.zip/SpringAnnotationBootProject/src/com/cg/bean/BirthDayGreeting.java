package com.cg.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("obj2")
public class BirthDayGreeting implements IGreet,BeanNameAware,BeanFactoryAware,
DisposableBean,InitializingBean{
	@Value("Avinash")
	String  firstName;
	
	public BirthDayGreeting() {
		System.out.println("In BirthDayGreeting "+"Constructor");
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("setFirstName called......");
	}
	@Override
	public String greetMe() {
		
		return "Happy Birthday: " + firstName;
	}
	public BirthDayGreeting(String firstName) {
		super();
		this.firstName = firstName;
	}
	@Override
	public void setBeanName(String beanName) {
		System.out.println("In setBeanName()....."+beanName);
	}
	@Override
	public void setBeanFactory(BeanFactory bf) throws BeansException {
		System.out.println("In setBeanFactory()-----"+bf.toString());
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("This is called after firstname set......");
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("Destroy is called.......");
	}
	public void cgInit() {
		System.out.println("This is custom cgInit");
	}
	public void cgDestroy() {
		System.out.println("This is custom cg Destroy");
	}
}
