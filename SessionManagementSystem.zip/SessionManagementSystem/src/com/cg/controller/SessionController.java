package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.dto.Session;
import com.cg.service.ISessionService;

@Controller
public class SessionController {
	@Autowired
	ISessionService sessionService=null;

	public ISessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(ISessionService sessionService) {
		this.sessionService = sessionService;
	}
	/************************Get All Sessions*******************/
	@RequestMapping(value="/ScheduledSessions", method=RequestMethod.GET)
	public String getAllSessionDeatils(Model model) {
					ArrayList<Session> sessionList= sessionService.getAllSessionsDetails();
					model.addAttribute("sessionListObj", sessionList);
					return "ScheduledSessions";
		}
	
	/*********************** Enroll Me*************************/
	@RequestMapping(value = "/EnrollMe", method = RequestMethod.GET)
    public String showSuccessPage(@RequestParam(value="uid") String sessionName,Model model) {
        model.addAttribute("session", sessionName);
        return "EnrollMe";
    }
}
