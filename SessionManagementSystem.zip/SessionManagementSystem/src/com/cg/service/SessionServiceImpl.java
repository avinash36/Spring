package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ISessionDao;
import com.cg.dto.Session;
@Service
public class SessionServiceImpl implements ISessionService {
@Autowired
ISessionDao sessionDao=null;

	public ISessionDao getSessionDao() {
	return sessionDao;
}

public void setSessionDao(ISessionDao sessionDao) {
	this.sessionDao = sessionDao;
}

	@Override
	public ArrayList<Session> getAllSessionsDetails() {
		return sessionDao.getAllSessionsDetails();
	}

}
