package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Session;

public interface ISessionService {
	public ArrayList<Session> getAllSessionsDetails();
}
