package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.cg.dto.Session;
@Repository
@Transactional
public class SessionDaoImpl implements ISessionDao {
	@PersistenceContext
	EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public ArrayList<Session> getAllSessionsDetails() {
		String qry="SELECT reg FROM Session reg";
		TypedQuery tq=entityManager.createQuery(qry, Session.class);
		ArrayList<Session> sessionList=(ArrayList) tq.getResultList();
		return sessionList;
		//return (ArrayList<Session>) entityManager.createQuery("from Session s", Session.class).getResultList();
	}

}
