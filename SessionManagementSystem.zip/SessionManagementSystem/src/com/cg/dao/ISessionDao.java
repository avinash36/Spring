package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Session;

public interface ISessionDao {
	public ArrayList<Session> getAllSessionsDetails();
}
