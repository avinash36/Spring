package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
@Service("loginSer")
public class LoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDao logDao=null;
	public ILoginDao getLogDao() {
		return logDao;
	}

	public void setLogDao(ILoginDao logDao) {
		this.logDao = logDao;
	}

	@Override
	public boolean isUserExist(String usn) {
		return logDao.isUserExist(usn);
	}

	@Override
	public Login validateUser(Login login) {
		Login dbUser=logDao.validateUser(login);
		if (login.getUserName().equalsIgnoreCase(dbUser.getUserName())&& login.getPassword().equalsIgnoreCase(dbUser.getPassword())){
			return login;
		}else {
			return null;
		}
	}

	@Override
	public RegisterDto insertuserDetails(RegisterDto userDetails) {
		
		return logDao.insertuserDetails(userDetails);
	}

	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		return logDao.getAllUserDetails();
	}

	@Override
	public RegisterDto deleteUsers(String usn) {
		return logDao.deleteUsers(usn);
	}

}
