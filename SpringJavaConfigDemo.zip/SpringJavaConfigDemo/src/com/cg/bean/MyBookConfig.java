package com.cg.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBookConfig {
	@Bean
	public Author author() {
		return new Author("Chetan Bhagat", "Delhi");
	}
	
	@Bean(initMethod="setUp", destroyMethod="cleanUp")
	public Book book() {
		Book book=new Book();
		book.setYear("1992");
		book.setIsbn("kdj333");
		book.setAuthor(author());
		return book;
	}
}
