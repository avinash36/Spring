package com.cg.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Customer_Details")
public class CustomerDetails {
	@Id
	@Column(name="Pan_Card_Number", length=10)
	private String panCardNo;

	@Column(name="Customer_Name", length=20)
	private String customerName;

	@Column(name="Email_Id", length=30)
	private String emailId;

	@Column(name="Mobile_Number", length=10)
	private int mobileNo;

	@Column(name="Cibil_Score", length=3)
	private int cibilScore;
	public CustomerDetails() {}

	public CustomerDetails(String panCardNo, String customerName, String emailId, int mobileNo, int cibilScore) {
		super();
		this.panCardNo = panCardNo;
		this.customerName = customerName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.cibilScore = cibilScore;
	}

	@NotEmpty(message="PANCARDNUMBER is mandatory to enter to test your eligibility")
	@Pattern(regexp="[A-Za-z]{5}\\d{4}[A-Za-z]{1}",message="Please follow the correct format. EX:ABCDE1234Z")
	public String getPanCardNo() {
		return panCardNo;
	}


	public void setPanCardNo(String panCardNo) {
		this.panCardNo = panCardNo;
	}


	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(int cibilScore) {
		this.cibilScore = cibilScore;
	}


	@Override
	public String toString() {
		return "CustomerDetails [panCardNo=" + panCardNo + ", customerName=" + customerName + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + ", cibilScore=" + cibilScore + "]";
	}

}
