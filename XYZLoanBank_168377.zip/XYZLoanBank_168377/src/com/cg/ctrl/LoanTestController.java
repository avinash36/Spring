package com.cg.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.CustomerDetails;
import com.cg.service.ILoanTestService;


@Controller
public class LoanTestController {
	@Autowired
	ILoanTestService iloanservice=null;	

	public ILoanTestService getIloanservice() {
		return iloanservice;
	}

	public void setIloanservice(ILoanTestService iloanservice) {
		this.iloanservice = iloanservice;
	}

	@RequestMapping(value="/ShowTestEligibilityPage")
	public String dispRegPage(Model model) {
		CustomerDetails rd=new CustomerDetails();
		model.addAttribute("reg",rd);

		return "acceptpancard";

	}

	@RequestMapping(value="/testPanCard",method=RequestMethod.POST)
	public String testPancard(@ModelAttribute(value="reg") CustomerDetails customerDetails,BindingResult result,Model model) {

		CustomerDetails cd=	iloanservice.findDetails(customerDetails.getPanCardNo());
		if(cd.getCibilScore()>=750) {
			model.addAttribute("CustObj", cd);
			return "testSuccess";
		}
		else {
			model.addAttribute("CustObj", cd);
			return "testFail";
		}
	}











}
