package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.CustomerDetails;
import com.cg.dao.ILoanTestDAO;
import com.cg.dao.LoanTestDAOImpl;

@Service
public class LoanTestServiceImpl implements ILoanTestService{
	@Autowired
	ILoanTestDAO loandao=new LoanTestDAOImpl();

	public ILoanTestDAO getLoandao() {
		return loandao;
	}

	public void setLoandao(ILoanTestDAO loandao) {
		this.loandao = loandao;
	}

	@Override
	public CustomerDetails findDetails(String panCard) {
		return loandao.findDetails(panCard);
	}

	@Override
	public CustomerDetails validatePanCard(CustomerDetails customerDetails) {
		CustomerDetails cdet=loandao.validatePanCard(customerDetails);
		if (customerDetails.getPanCardNo().equalsIgnoreCase(cdet.getPanCardNo())){
			return customerDetails;
		}else {
			return null;
		}
	}
}

