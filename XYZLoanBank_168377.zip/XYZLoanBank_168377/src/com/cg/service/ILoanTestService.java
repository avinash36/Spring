package com.cg.service;

import com.cg.bean.CustomerDetails;

public interface ILoanTestService {
	public CustomerDetails validatePanCard(CustomerDetails customerDetails);
	public CustomerDetails findDetails(String panCard);
}
