package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.CustomerDetails;

@Repository
@Transactional
public class LoanTestDAOImpl implements ILoanTestDAO
{
	@PersistenceContext
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public CustomerDetails findDetails(String panCard) {
		return entityManager.find(CustomerDetails.class, panCard);
	}

	@Override
	public CustomerDetails validatePanCard(CustomerDetails customerDetails) {
		CustomerDetails cDetails=entityManager.find(CustomerDetails.class,customerDetails.getPanCardNo());
		return cDetails;
	}

}
