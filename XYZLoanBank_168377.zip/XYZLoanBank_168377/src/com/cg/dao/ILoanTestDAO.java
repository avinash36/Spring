package com.cg.dao;

import com.cg.bean.CustomerDetails;

public interface ILoanTestDAO {
	public CustomerDetails findDetails(String panCard);
	public CustomerDetails validatePanCard(CustomerDetails customerDetails);
}
