package com.cg.service;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;

public interface ILoginService {
	public boolean isUserExist(String usn);
	public boolean isMercUserExist(String musn);
	public Login validateUser(Login login);
	public MerchantLogin validateUser(MerchantLogin mlogin);
}
