package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
@Service("loginSer")
public class LoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDao logDao=null;
	public ILoginDao getLogDao() {
		return logDao;
	}

	public void setLogDao(ILoginDao logDao) {
		this.logDao = logDao;
	}

	@Override
	public boolean isUserExist(String usn) {
		return logDao.isUserExist(usn);
	}

	@Override
	public Login validateUser(Login login) {
		Login dbUser=logDao.validateUser(login);
		if (login.getUserEmail().equalsIgnoreCase(dbUser.getUserEmail())&& login.getPassword().equalsIgnoreCase(dbUser.getPassword())){
			return login;
		}else {
			return null;
		}
	}

	@Override
	public MerchantLogin validateUser(MerchantLogin mlogin) {
		MerchantLogin dbmlogin=logDao.validateUser(mlogin);
		if (mlogin.getMerchant_emailId().equalsIgnoreCase(dbmlogin.getMerchant_emailId())&& mlogin.getPassword().equalsIgnoreCase(dbmlogin.getPassword())){
			return mlogin;
		}else {
			return null;
		}
	}

	@Override
	public boolean isMercUserExist(String musn) {
		return logDao.isMercUserExist(musn);
	}

}