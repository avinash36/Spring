package com.cg.dao;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;

public interface ILoginDao {
	public boolean isUserExist(String usn);
	public boolean isMercUserExist(String musn);
	public Login validateUser(Login login);
	public MerchantLogin validateUser(MerchantLogin mlogin);
}
