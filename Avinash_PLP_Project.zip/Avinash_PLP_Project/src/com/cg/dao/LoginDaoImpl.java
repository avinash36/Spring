package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Login;
import com.cg.dto.MerchantLogin;
@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String usn) {
		Login usr=entityManager.find(Login.class, usn);
		if(usr!=null) {
			return true;
		}else {
			return false;
		}	
	}

	@Override
	public Login validateUser(Login login) {
		Login usr=entityManager.find(Login.class,login.getUserEmail());
		return usr;
	}

	@Override
	public MerchantLogin validateUser(MerchantLogin mlogin) {
		MerchantLogin mlog=entityManager.find(MerchantLogin.class,mlogin.getMerchant_emailId());
		return mlog;
	}

	@Override
	public boolean isMercUserExist(String musn) {
		MerchantLogin mlog=entityManager.find(MerchantLogin.class, musn);
		if(mlog!=null) {
			return true;
		}else {
			return false;
		}	
	}
}