package com.cg.dao;
import com.cg.dto.CustomerDetails;
public interface ILoanTestDAO {
	public boolean isPanCardNoExist(String pce);
	public CustomerDetails validatePanCard(CustomerDetails customerDetails);
	public CustomerDetails find(String pancard);
}
