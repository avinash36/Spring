package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.CustomerDetails;


@Repository
@Transactional
public class LoanTestDAOImpl implements ILoanTestDAO{
	
	@PersistenceContext
	EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isPanCardNoExist(String pce) {
		CustomerDetails cDetails=entityManager.find(CustomerDetails.class, pce);
		if(cDetails!=null) {
			return true;
		}else {
			return false;
		}	
	}
	

	@Override
	public CustomerDetails validatePanCard(CustomerDetails customerDetails) {
		CustomerDetails cDetails=entityManager.find(CustomerDetails.class,customerDetails.getPanCardNo());
		return cDetails;
	}

	@Override
	public CustomerDetails find(String pancard) {
		// TODO Auto-generated method stub
		return entityManager.find(CustomerDetails.class, pancard);
	}

}
