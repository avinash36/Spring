package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.CustomerDetails;
import com.cg.service.ILoanTestService;


@Controller
public class LoanTestController {
	
	@Autowired
	ILoanTestService loanTest=null;
	
	public ILoanTestService getLoanTest() {
		return loanTest;
	}
	public void setLoanTest(ILoanTestService loanTest) {
		this.loanTest = loanTest;
	}

	@RequestMapping(value="/Eligibility", method=RequestMethod.GET)
	public String displayAcceptPanCardPage(Model model) {
		CustomerDetails cd=new CustomerDetails();
		model.addAttribute("cusdet", cd);
	
		return "acceptpancard";
	}
	
	
	/************************Validate*******************/
	@RequestMapping(value="/validate", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="cusdet") 
			@Valid CustomerDetails cd, BindingResult result,Model model) {
		if(result.hasErrors()) {
			return "acceptpancard";
		}else {
			if(loanTest.isPanCardNoExist(cd.getPanCardNo())) {
			CustomerDetails cusDe=loanTest.validatePanCard(cd);
			if(cusDe!=null){
					model.addAttribute("panNoDetails",cd.getPanCardNo());		
				return "Success";
				}else {
					return "Error1";
				}
			}else {
				return  "Error2";
			}
		}
	}
	
	
	
	@RequestMapping(value="/test", method=RequestMethod.POST)
	public String testEligibility(@ModelAttribute(value="cusdet")
	@Valid CustomerDetails cd, BindingResult result,Model model) {
		
		CustomerDetails customerDetails=loanTest.find( cd.getPanCardNo());
		if(customerDetails.getCibilScore()>=750) {
			model.addAttribute("CustomerObj", customerDetails);
			return "Success";
		}
		else {
			model.addAttribute("CustomerObj", customerDetails);
		return "error";
		}
	}
	
}