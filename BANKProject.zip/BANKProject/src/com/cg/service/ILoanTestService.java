package com.cg.service;

import com.cg.dto.CustomerDetails;

public interface ILoanTestService {
	public boolean isPanCardNoExist(String pce);
	public CustomerDetails validatePanCard(CustomerDetails customerDetails);
	public CustomerDetails find(String pancard);
}
