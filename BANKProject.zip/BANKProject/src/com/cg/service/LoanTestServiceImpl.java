package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoanTestDAO;
import com.cg.dto.CustomerDetails;

@Service
public class LoanTestServiceImpl implements ILoanTestService {
	@Autowired
	ILoanTestDAO loanDao=null;

	public ILoanTestDAO getLoanDao() {
		return loanDao;
	}

	public void setLoanDao(ILoanTestDAO loanDao) {
		this.loanDao = loanDao;
	}

	@Override
	public boolean isPanCardNoExist(String pce) {

		return loanDao.isPanCardNoExist(pce);
	}

	@Override
	public CustomerDetails validatePanCard(CustomerDetails customerDetails) {
		CustomerDetails cdet=loanDao.validatePanCard(customerDetails);
		if (customerDetails.getPanCardNo().equalsIgnoreCase(cdet.getPanCardNo())){
			return customerDetails;
		}else {
			return null;
		}
	}

	@Override
	public CustomerDetails find(String pancard) {
		// TODO Auto-generated method stub
		return loanDao.find(pancard);
	}
	
}
