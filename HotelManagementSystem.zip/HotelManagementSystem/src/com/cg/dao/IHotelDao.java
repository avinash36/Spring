package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Hotel;

public interface IHotelDao {
	public ArrayList<Hotel> getAllHotelsList();
}
