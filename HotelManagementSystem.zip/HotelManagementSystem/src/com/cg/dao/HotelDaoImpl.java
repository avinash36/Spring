package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Hotel;
@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao {
	@PersistenceContext
	EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public ArrayList<Hotel> getAllHotelsList() {
		String qry="SELECT reg FROM Hotel reg";
		TypedQuery tq=entityManager.createQuery(qry, Hotel.class);
		ArrayList<Hotel> hotelList=(ArrayList) tq.getResultList();
		return hotelList;
	}

}
