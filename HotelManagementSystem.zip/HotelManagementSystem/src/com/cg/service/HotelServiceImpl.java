package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IHotelDao;
import com.cg.dto.Hotel;
@Service
public class HotelServiceImpl implements IHotelService {
	@Autowired
	IHotelDao hotelDao=null;
	
	public IHotelDao getHotelDao() {
		return hotelDao;
	}

	public void setHotelDao(IHotelDao hotelDao) {
		this.hotelDao = hotelDao;
	}

	@Override
	public ArrayList<Hotel> getAllHotelsList() {
		return hotelDao.getAllHotelsList();
	}
	
}
