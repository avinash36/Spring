package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Hotel;

public interface IHotelService {
	public ArrayList<Hotel> getAllHotelsList();
}
