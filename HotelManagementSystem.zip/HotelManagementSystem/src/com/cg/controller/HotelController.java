package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Hotel;
import com.cg.service.IHotelService;

@Controller
public class HotelController {
	@Autowired
	IHotelService hotelService=null;

	public IHotelService getHotelService() {
		return hotelService;
	}

	public void setHotelService(IHotelService hotelService) {
		this.hotelService = hotelService;
	}
	/************************Get All Hotels*******************/
	@RequestMapping(value="/HotelDetails", method=RequestMethod.GET)
	public String getAllHotelList(Model model) {
					ArrayList<Hotel> hotelList= hotelService.getAllHotelsList();
					model.addAttribute("hotelsListObj", hotelList);
					return "HotelDetails";
		}
	
	/*********************** Book Hotel*************************/
	@RequestMapping(value = "/BookHotel", method = RequestMethod.GET)
    public String showBookingConfirmation(@RequestParam(value="uid") String name,Model model) {
        model.addAttribute("hotelName", name);
        return "BookingConfirmation";
    }
}
