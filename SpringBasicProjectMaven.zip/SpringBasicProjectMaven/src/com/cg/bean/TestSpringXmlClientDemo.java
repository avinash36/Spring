package com.cg.bean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestSpringXmlClientDemo {
	public static void main(String[] args) {
		Resource resources= new ClassPathResource("cg.xml");
		BeanFactory bf=new XmlBeanFactory(resources);
		IGreet g1=(IGreet) bf.getBean("obj1");
		System.out.println(g1.greetMe());
		
		System.out.println(g1.hashCode());
		
		IGreet g2=(IGreet) bf.getBean("obj1");
		System.out.println(g2.greetMe());
		
		System.out.println(g2.hashCode());
	}
}
