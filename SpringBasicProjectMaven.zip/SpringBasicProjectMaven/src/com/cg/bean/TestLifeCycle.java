package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestLifeCycle {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cg.xml");
		IGreet g1=(IGreet) ctx.getBean("obj1");
		System.out.println(g1.greetMe());
	}

}
