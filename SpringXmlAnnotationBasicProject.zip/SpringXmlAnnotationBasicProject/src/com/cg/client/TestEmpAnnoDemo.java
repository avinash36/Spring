package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Emp;
import com.cg.bean.Employee;
import com.cg.bean.User;

public class TestEmpAnnoDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXmlAnno.xml");
		Employee emp1=(Employee) ctx.getBean("aviEmp1");
		System.out.println(emp1);
		System.out.println("------------------------------------");
		Emp emp2= (Emp) ctx.getBean("e2");
		System.out.println(emp2);
		System.out.println("--------------------------------------");
		User myCredentials=(User) ctx.getBean("u1");
		System.out.println(myCredentials);
	}

}
