package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;

public class NewYearWish implements IGreet{
	
	@Value("Avinash")
	String  firstName;
	@Value("2000")
	int year;
	
	public NewYearWish() {
		System.out.println("In NewYearGreeting "+"Constructor");
	}
	
	public NewYearWish(String firstName, int year) {
		super();
		this.firstName = firstName;
		this.year = year;
		System.out.println("In NewYearWish parameter Constructor...");
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("setFirstName called");
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
		System.out.println("setYear called");
	}
	@Override
	public String greetMe() {
		
		return "Happy New Year " +year +":"+" "+ firstName ;
	}

}
