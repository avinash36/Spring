package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<Address> getAddList(){
		Address a1=new Address();
		a1.setCity("Mumbai");
		a1.setState("maharastra");
		a1.setZipCode(232211);
		
		Address a2=new Address();
		a2.setCity("Varanasi");
		a2.setState("Uttar Pradesh");
		a2.setZipCode(232322);
		
		ArrayList<Address> adList= new ArrayList<Address>();
		adList.add(a1);
		adList.add(a2);
		return adList;
	}
}
